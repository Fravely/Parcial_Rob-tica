"""arm_broker — el único nodo que publica en /joint_states.

Andamiaje entregado por el curso. Lo propio (lo que se califica) son los bloques
IMPLEMENTAR del ítem 2: goal_callback, handle_accepted_callback, _worker y
execute_callback, más las políticas de politicas.py y la FK de fk.py.

Idea en una frase: UN portero (goal_callback) decide quién entra, UNA sala de espera
(self.pendientes) guarda a los aceptados, y UN trabajador (_worker) atiende de a uno.
"""

import csv
import os
import threading
import time

import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState

from arm_broker_interfaces.action import MoveArm
from arm_broker_interfaces.msg import QueueState

from arm_broker import fk
from arm_broker.politicas import POLITICAS, Pedido


class ArmBroker(Node):

    def __init__(self):
        super().__init__('arm_broker')

        # ----- parámetros (se cambian con --ros-args -p nombre:=valor; usa decimales: 2.0, no 2)
        self.declare_parameter('politica', 'fifo')
        self.declare_parameter('tau_envejecimiento_s', 8.0)
        self.declare_parameter('cola_max', 20)
        self.declare_parameter('paso_max_rad', 1.2)
        self.declare_parameter('duracion_movimiento_s', 3.0)
        self.declare_parameter('pasos_interpolacion', 10)
        # Pose en la que SE SUPONE que está el brazo al arrancar el broker (la base = ceros).
        self.declare_parameter('q_inicial_rad', [0.0] * 6)
        # Archivo donde se anota cada rechazo con su motivo ('' = no escribir archivo).
        self.declare_parameter('archivo_rechazos', 'registro_rechazos.csv')

        nombre = self.get_parameter('politica').value
        if nombre not in POLITICAS:
            raise RuntimeError(f'política desconocida: {nombre}. Hay {list(POLITICAS)}')
        clase = POLITICAS[nombre]
        if nombre == 'prioridad':
            self.politica = clase(self.get_parameter('tau_envejecimiento_s').value)
        else:
            self.politica = clase()

        self.cola_max = int(self.get_parameter('cola_max').value)
        self.paso_max = float(self.get_parameter('paso_max_rad').value)
        self.duracion = float(self.get_parameter('duracion_movimiento_s').value)
        self.pasos = max(1, int(self.get_parameter('pasos_interpolacion').value))
        self.archivo_rechazos = str(self.get_parameter('archivo_rechazos').value)

        # ----- grupos de callbacks
        # Reentrante: varios callbacks a la vez (aceptar goals MIENTRAS otro se ejecuta).
        # Exclusivo: sus callbacks corren de uno en uno (el temporizador de la cola).
        # OJO: la exclusión mutua del BRAZO no la dan los grupos, la da el worker único.
        self.grupo_entrada = ReentrantCallbackGroup()
        self.grupo_worker = MutuallyExclusiveCallbackGroup()

        # ----- estado compartido: TODO acceso a estas variables va bajo self.lock
        self.lock = threading.Lock()
        self._lock_archivo = threading.Lock()
        self.pendientes = []            # la sala de espera (lista de Pedido)
        self.por_goal_id = {}           # índice goal_id -> Pedido, para execute_callback
        self.ejecutando = None          # el Pedido que mueve el brazo AHORA (o None)
        q0 = list(self.get_parameter('q_inicial_rad').value)
        if len(q0) != 6:
            self.get_logger().warn('q_inicial_rad debe tener 6 valores; uso ceros')
            q0 = [0.0] * 6
        self.q_actual = q0
        self.n_aceptados = 0
        self.n_rechazados = 0
        self.n_completados = 0
        self._parar = threading.Event()

        self.pub_joint = self.create_publisher(JointState, '/joint_states', 10)
        self.pub_cola = self.create_publisher(QueueState, '/arm/queue_state', 10)

        self.servidor = ActionServer(
            self,
            MoveArm,
            'move_arm',
            goal_callback=self.goal_callback,
            handle_accepted_callback=self.handle_accepted_callback,
            cancel_callback=self.cancel_callback,
            execute_callback=self.execute_callback,
            callback_group=self.grupo_entrada,
        )

        # /arm/queue_state a 5 Hz
        self.create_timer(0.2, self.publicar_estado_cola,
                          callback_group=self.grupo_worker)

        # El trabajador único
        self.worker = threading.Thread(target=self._worker, daemon=True)
        self.worker.start()

        self.get_logger().info(
            f'arm_broker listo · política={self.politica.nombre} · '
            f'cola_max={self.cola_max} · paso_max={self.paso_max:.2f} rad · '
            f'único publicador de /joint_states')

    # ========================= IMPLEMENTAR · ítem 2 ==========================
    def goal_callback(self, goal_request):
        """EL PORTERO. Admisión barata e inmediata: acepta o rechaza, NUNCA ejecuta.

        Los filtros van del más barato al más caro. Cada rechazo lleva un motivo legible
        con los números que lo causaron (lo exige la rúbrica).
        """
        q = list(goal_request.joint_positions)
        cliente = goal_request.client_id or '?'

        # 1) Límites articulares (comparación directa, no necesita FK)
        ok, motivo = fk.dentro_de_limites(q)
        if not ok:
            return self._rechazar(cliente, f'límites articulares: {motivo}', q)

        # 2) Workspace (aquí entra tu FK: distancia a la base y z >= 0)
        ok, motivo = fk.dentro_del_workspace(q)
        if not ok:
            return self._rechazar(cliente, f'workspace: {motivo}', q)

        # 3) Paso articular desde la pose actual del brazo
        with self.lock:
            desde = list(self.q_actual)
            en_cola = len(self.pendientes)
        paso = fk.paso_articular(desde, q)
        if paso > self.paso_max:
            return self._rechazar(
                cliente, f'paso articular excesivo: {paso:.2f} rad, máximo {self.paso_max:.2f}', q)

        # 4) ¿Hay sitio en la sala de espera?
        if en_cola >= self.cola_max:
            return self._rechazar(cliente, f'cola llena ({en_cola}/{self.cola_max})', q)

        with self.lock:
            self.n_aceptados += 1
        x, y, z = fk.fk(q)
        self.get_logger().info(f'ACEPTADO  {cliente}  ->  ({x:.0f}, {y:.0f}, {z:.0f}) mm')
        return GoalResponse.ACCEPT

    def _rechazar(self, cliente, motivo, q=None):
        """Cuenta el rechazo, lo escribe en el log y en registro_rechazos.csv."""
        with self.lock:
            self.n_rechazados += 1
        self.get_logger().warn(f'RECHAZADO {cliente}: {motivo}')
        self._anotar_rechazo(cliente, motivo, q)
        return GoalResponse.REJECT

    def _anotar_rechazo(self, cliente, motivo, q):
        if not self.archivo_rechazos:
            return
        try:
            with self._lock_archivo:
                nuevo = not os.path.exists(self.archivo_rechazos)
                with open(self.archivo_rechazos, 'a', newline='') as f:
                    w = csv.writer(f)
                    if nuevo:
                        w.writerow(['hora', 'cliente', 'motivo', 'q_pedida_rad'])
                    w.writerow([time.strftime('%Y-%m-%dT%H:%M:%S'), cliente, motivo,
                                '' if q is None else ' '.join(f'{v:.3f}' for v in q)])
        except OSError as e:                      # el archivo es un extra: nunca tumba la admisión
            self.get_logger().warn(f'no pude escribir {self.archivo_rechazos}: {e}')

    def handle_accepted_callback(self, goal_handle):
        """LA SALA DE ESPERA. Solo encola: aquí NO se ejecuta nada ni se publica nada.

        Corre en el grupo reentrante (varios clientes a la vez), por eso toda escritura a
        self.pendientes va bajo self.lock.
        """
        pedido = Pedido(goal_handle,
                        goal_handle.request.client_id,
                        goal_handle.request.priority,
                        goal_handle.request.joint_positions)
        with self.lock:
            self.pendientes.append(pedido)
            self.por_goal_id[pedido.goal_id] = pedido
            posicion = len(self.pendientes)
        self.get_logger().info(
            f'ENCOLADO  {pedido.client_id}  posición {posicion}  (no se ejecuta aquí)')

    def _worker(self):
        """EL TRABAJADOR ÚNICO. Un solo hilo decide a quién le toca y atiende de a uno."""
        while not self._parar.is_set():
            pedido = None
            descartado = None
            with self.lock:
                # Solo se saca otro pedido si nadie se está ejecutando (1.ª defensa)
                if self.ejecutando is None and self.pendientes:
                    idx = self.politica.siguiente(self.pendientes)   # la política decide
                    if idx is not None:
                        pedido = self.pendientes.pop(idx)
                        if pedido.goal_handle.is_cancel_requested:
                            self.por_goal_id.pop(pedido.goal_id, None)
                            descartado, pedido = pedido, None
                        else:
                            self.ejecutando = pedido
                            pedido.t_inicio_ejec = time.time()

            if descartado is not None:
                # Cancelado mientras esperaba: hay que CERRAR el goal o el cliente se cuelga
                try:
                    descartado.goal_handle.canceled()
                except Exception as e:
                    self.get_logger().warn(f'no pude cerrar el goal cancelado: {e}')
                self.get_logger().info(f'CANCELADO en cola {descartado.client_id}')
                continue

            if pedido is None:
                time.sleep(0.02)                  # nada que hacer: no quemes CPU
                continue

            try:
                pedido.goal_handle.execute()      # dispara execute_callback en otro hilo
            except Exception as e:
                self.get_logger().error(f'execute() falló: {e}')
                try:
                    pedido.goal_handle.abort()
                except Exception:
                    pass
                pedido.fin.set()

            # EXCLUSIÓN MUTUA: no se saca otro pedido hasta que este termine.
            # Se espera con timeout para que Ctrl+C pueda cerrar limpio.
            while not pedido.fin.wait(0.5):
                if self._parar.is_set():
                    break

            with self.lock:
                self.ejecutando = None
                self.por_goal_id.pop(pedido.goal_id, None)
                # solo cuenta como completado el que terminó con éxito
                if pedido.resultado is not None and pedido.resultado.success:
                    self.n_completados += 1
            self.politica.atendido(pedido)

    def execute_callback(self, goal_handle):
        """Ejecuta UN pedido (lo llama el worker vía goal_handle.execute(), nunca handle_accepted).

        Interpola desde q_actual hasta el destino en self.pasos pasos y publica cada paso con
        mover(), que es el ÚNICO punto del programa que publica en /joint_states.
        """
        gid = bytes(goal_handle.goal_id.uuid).hex()[:12]
        with self.lock:
            pedido = self.por_goal_id.get(gid)
        resultado = MoveArm.Result()

        if pedido is None:
            goal_handle.abort()
            resultado.success = False
            resultado.message = 'pedido desconocido'
            return resultado

        try:
            destino = list(pedido.joint_positions)
            with self.lock:
                desde = list(self.q_actual)
            t0 = time.time()
            dt = self.duracion / self.pasos           # p. ej. 3.0 s / 10 pasos = 0.3 s por paso
            self.get_logger().info(
                f'EJECUTANDO {pedido.client_id}  goal={pedido.goal_id}  '
                f'espera={pedido.espera_s:.2f}s')

            for paso in range(1, self.pasos + 1):
                if goal_handle.is_cancel_requested:   # ¿lo cancelaron a mitad de camino?
                    goal_handle.canceled()
                    resultado.success = False
                    resultado.message = f'cancelado en el paso {paso}/{self.pasos}'
                    resultado.wait_time_s = pedido.espera_s
                    resultado.exec_time_s = time.time() - t0
                    return resultado

                frac = paso / self.pasos              # 0.1, 0.2, ... 1.0
                q = [a + (b - a) * frac for a, b in zip(desde, destino)]
                self.mover(q)                         # ← única publicación en /joint_states

                fb = MoveArm.Feedback()
                fb.state = 'EXECUTING'
                fb.queue_position = 0
                fb.elapsed_s = time.time() - t0
                goal_handle.publish_feedback(fb)
                time.sleep(dt)

            goal_handle.succeed()
            x, y, z = fk.fk(destino)
            resultado.success = True
            resultado.message = f'llegó a ({x:.0f}, {y:.0f}, {z:.0f}) mm'
            resultado.wait_time_s = pedido.espera_s
            resultado.exec_time_s = time.time() - t0
            self.get_logger().info(
                f'COMPLETADO {pedido.client_id}  goal={pedido.goal_id}  '
                f'espera={resultado.wait_time_s:.2f}s ejec={resultado.exec_time_s:.2f}s')
            return resultado
        except Exception as e:                        # un fallo no debe dejar el brazo bloqueado
            self.get_logger().error(f'falló la ejecución de {pedido.client_id}: {e}')
            try:
                goal_handle.abort()
            except Exception:
                pass
            resultado.success = False
            resultado.message = f'error: {e}'
            return resultado
        finally:
            # PASE LO QUE PASE: si no se levanta la bandera, el worker espera para siempre
            pedido.resultado = resultado
            pedido.fin.set()
    # =========================================================================

    def cancel_callback(self, goal_handle):
        return CancelResponse.ACCEPT

    # ----------------------------------------------------------- publicar
    def mover(self, q):
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.name = fk.JOINT_NAMES
        msg.position = [float(v) for v in q]
        self.pub_joint.publish(msg)
        with self.lock:
            self.q_actual = list(q)

    def publicar_estado_cola(self):
        msg = QueueState()
        msg.stamp = self.get_clock().now().to_msg()
        with self.lock:
            ej = self.ejecutando
            msg.executing_client = ej.client_id if ej else ''
            msg.executing_goal_id = ej.goal_id if ej else ''
            msg.executing_elapsed_s = (time.time() - ej.t_inicio_ejec) if ej and ej.t_inicio_ejec else 0.0
            msg.queue_length = len(self.pendientes)
            msg.queued_goal_ids = [p.goal_id for p in self.pendientes]
            msg.queued_clients = [p.client_id for p in self.pendientes]
            msg.queued_priorities = [min(255, max(0, p.priority)) for p in self.pendientes]
            msg.queued_wait_s = [p.espera_s for p in self.pendientes]
            msg.total_accepted = self.n_aceptados
            msg.total_rejected = self.n_rechazados
            msg.total_completed = self.n_completados
            cola = list(self.pendientes)
        self.pub_cola.publish(msg)

        for posicion, p in enumerate(cola, start=1):
            try:
                fb = MoveArm.Feedback()
                fb.state = 'QUEUED'
                fb.queue_position = posicion
                fb.elapsed_s = p.espera_s
                p.goal_handle.publish_feedback(fb)
            except Exception:
                pass

    def destroy_node(self):
        self._parar.set()
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    nodo = ArmBroker()
    # 8 hilos: holgura para que un movimiento de 3 s no deje sin hilo a la admisión
    executor = MultiThreadedExecutor(num_threads=8)
    executor.add_node(nodo)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
